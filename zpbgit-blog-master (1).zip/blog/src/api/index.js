import axios from 'axios'
import Qs from 'qs'
import store from 'STORE/index'

import {
  getAccessToken,
  removeAccessToken,
  cachedAdminInfo
} from 'API/cacheService'

import {
  IS_LOGIN,
  SHOW_TOKEN_ERROR
} from 'STORE/mutation-types'

/* eslint-disable */
const API_ROOT_DEV_IP = '101.132.109.226:8088'
const API_ROOT = 'http://101.132.109.226:8088/Blog'//生产环境请求路径
const API_ROOT_DEV = 'http://' + API_ROOT_DEV_IP + '/Blog'//本地环境请求路径

/* eslint-enable */
axios.defaults.baseURL = (process.env.NODE_ENV === 'production' ? API_ROOT : API_ROOT_DEV)

axios.defaults.headers.Accept = 'application/json'

// Add a request interceptor
axios.interceptors.request.use(function (config) {
  // if (config.url.indexOf('a/') === 0) {
  if (getAccessToken()) {
    config.headers['accessToken'] = getAccessToken()
  }
  // }
  return config
}, function (error) {
  return Promise.reject(error)
})

// Add a response interceptor
axios.interceptors.response.use(function (response) {
  if (response.data.code < 0) {
    if (response.data.code === -4001) {
      // 清空登录信息
      removeAccessToken()
      cachedAdminInfo.delete()
      // // 弹出提示信息
      store.commit(SHOW_TOKEN_ERROR, true)
      // // 弹出登录窗口
      store.commit(IS_LOGIN, false)
    }
    let error = {
      msg: response.data.msg
    }
    return Promise.reject(error)
  }
  return response.data
}, function (error) {
  error = {
    msg: '请求出错'
  }
  return Promise.reject(error)
})

export default {
  /**
   * 管理员登录
   */
  adminLogin (params) {
    return axios.post('/login', params)
  },
  /**
   * 获取七牛token
   */
  getQiniuToken (withWater) {
    return axios.post('a/qiniu/token',
      {
        bucket: 'our-blog',
        withWater: withWater
      }
    )
  },
  /**
   * 上传图片到七牛
   */
  uploadToQiniu (params) {
    return axios.post('http://up-z0.qiniup.com', params, {
      headers: {
        'content-type': 'multipart/form-data'
      },
      withCredentials: false
    })
  },
  /**
   * 获取博客配置
   */
  getBlogConfig () {
    return axios.post('a/webConfig')
  },
  /**
   * 修改博客配置
   */
  modifyBlogConfig (params) {
    return axios.post('a/webConfig/modify', params)
  },
  /**
   * 获取 关于我 页面
   */
  getAboutMe () {
    return axios.post('a/webConfig/getAbout')
  },
  /**
   * 修改 关于我 页面
   */
  modifyAboutMe (params) {
    return axios.post('a/webConfig/modifyAbout', params)
  },
  /**
   * 获取首页面板显示的统计信息
   */
  getHomeStatistics () {
    return axios.post('a/statistics/home')
  },
  /**
   * 获取系统日志
   */
  getSysLog (params) {
    return axios.post('a/sys/log', {params: params})
  },
  /**
   * 添加分类
   */
  addCategory (categoryName) {
    return axios.post('a/category/add', {categoryName: categoryName})
  },
  /**
   * 添加标签
   */
  addTag (tagName) {
    return axios.post('a/tag/add', {tagName: tagName})
  },
  /**
   * 修改分类
   */
  modifyCategory (params) {
    return axios.post('a/category/modify', params)
  },
  /**
   * 修改标签
   */
  modifyTag (params) {
    return axios.post('a/tag/modify', params)
  },
  /**
   * 删除分类
   */
  deleteCategory (categoryId) {
    return axios.post('a/category/delete', {categoryId: categoryId})
  },
  /**
   * 删除标签
   */
  deleteTag (tagId) {
    return axios.post('a/tag/delete', {tagId: tagId})
  },
  /**
   * 获取分类列表
   */
  getCategoryList (params) {
    return axios.post('w/category/list', params)
  },
  /**
   * 获取标签列表
   */
  getTagList (params) {
    return axios.post('w/tag/list',
      params
    )
  },
  /**
   * 获取分类
   */
  getCategory (categoryId) {
    return axios.post('a/category', {
      params: {
        categoryId: categoryId
      }
    })
  },
  /**
   * 获取标签
   */
  getTag (tagId) {
    return axios.post('a/tag', {
      params: {
        tagId: tagId
      }
    })
  },
  /**
   * 保存文章
   */
  saveArticle (params) {
    return axios.post('a/article/save', params)
  },
  /**
   * 发布文章
   */
  publishArticle (params) {
    return axios.post('a/article/publish', params)
  },
  /**
   * 编辑文章
   */
  modifyArticle (params) {
    return axios.post('a/article/modify', params)
  },
  /**
   * 删除文章
   */
  deleteArticle (params) {
    return axios.post('a/article/delete', params)
  },
  /**
   * 获取文章信息
   */
  getArticle (articleId) {
    return axios.post('a/article/info',
      {
        id: articleId
      })
  },
  /**
   * 获取文章列表
   */
  getArticleList (params) {
    return axios.post('w/article/list', params)
  },
  /**
   * 获取友链列表
   */
  getFriendsList (params) {
    return axios.post('a/friends/list', params)
  },
  /**
   * 添加友链
   */
  addFriend (params) {
    return axios.post('a/friends/add', params)
  },
  /**
   * 编辑友链
   */
  modifyFriend (params) {
    return axios.post('a/friends/modify', params)
  },
  /**
   * 删除友链
   */
  deleteFriend (friendId) {
    return axios.post('a/friends/delete', Qs.stringify({friendId: friendId}))
  },
  /**
   * 获取友链类型列表
   */
  getFriendTypeList () {
    return axios.post('a/friends/typeList')
  },
  /**
   * 获取所有评论列表
   */
  getAllCommentsList (params) {
    return axios.post('a/comments/alllist', params)
  },
  /**
   * 获取文章评论列表
   */
  getComments (articleId) {
    return axios.post('w/comments/list', {articleId: articleId})
  },
  /**
   * 添加评论
   */
  adminReplyComments (params) {
    return axios.post('a/comments/add', params)
  },
  /**
   * 删除评论
   */
  deleteComments (id) {
    return axios.post('a/comments/delete', Qs.stringify({commentsId: id}))
  },
  /**
   * 获取 我的简历 页面
   */
  getResume () {
    return axios.post('a/webConfig/getResume')
  },
  /**
   * 修改 我的简历 页面
   */
  modifyResume (params) {
    return axios.post('a/webConfig/modifyResume', params)
  },
  // ---------------------------------------------以下是博客页面使用的接口---------------------------------------------,
  /**
   * 获取 关于我 页面
   */
  getBlogAboutMe () {
    return axios.post('w/getAbout')
  },
  /**
   * 获取博客信息
   */
  getBlogInfo () {
    return axios.post('w/blogInfo')
  },
  /**
   * 获取文章列表
   */
  getBlogArticleList (params) {
    if (params.by) {
      let by = params.by
      if (by === 'category') {
        delete params.tagId
      } else if (by === 'tag') {
        delete params.categoryId
      }
    }

    return axios.post('w/article/list', params)
  },
  /**
   * 获取文章归档列表
   */
  getBlogArticleArchives (params) {
    return axios.post('w/article/archives', params)
  },
  /**
   * 获取文章信息
   */
  getBlogArticle (id) {
    return axios.post('w/article', {id})
  },
  /**
   * 获取分类列表
   */
  getBlogCategoryList (params) {
    return axios.post('w/category/list', params)
  },
  /**
   * 获取标签列表
   */
  getBlogTagList (params) {
    return axios.post('w/tag/list', params)
  },
  /**
   * 获取友链列表
   */
  getBlogFriendsList () {
    return axios.post('w/friends/list')
  },
  /**
   * 获取文章评论列表
   */
  getBlogComments (articleId) {
    return axios.post('w/comments/list', {
      articleId: articleId
    })
  },
  /**
   * 添加评论
   */
  replyComments (params) {
    return axios.post('w/comments/add', params)
  },
  /**
   * 获取 我的简历 页面
   */
  getBlogResume () {
    return axios.post('w/getResume')
  },
  /**
   * 按文章标题和简介搜索
   */
  searchArticle (params) {
    return axios.post('w/article/search', params)
  }
}
