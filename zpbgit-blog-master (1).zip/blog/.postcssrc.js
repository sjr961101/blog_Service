// https://github.com/michael-ciniawsky/postcss-load-config

module.exports = {
  "plugins": {
    // "postcss-import": {},
    // "postcss-url": {},
    // 以上两个开启会报错，暂时不知道怎么回事
    // to edit target browsers: use "browserslist" field in package.json
    "autoprefixer": {}
  }
}
